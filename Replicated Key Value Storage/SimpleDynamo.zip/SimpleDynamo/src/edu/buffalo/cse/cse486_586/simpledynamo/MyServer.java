package edu.buffalo.cse.cse486_586.simpledynamo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import android.database.Cursor;
import android.util.Log;

public class MyServer implements Runnable {

	/* Defining the private variables here */
	private static final int SERVER_PORT = 10000;

	public void run() {
		try {
			ServerSocket servSoc = new ServerSocket(SERVER_PORT);

			while (true) {

				Socket soc = servSoc.accept();

				BufferedReader input = new BufferedReader(
						new InputStreamReader(soc.getInputStream()));
				String line = input.readLine();
				char type = line.charAt(0);
				String recv_msg;

				switch (type) {

				/*
				 * Coordinator Insert Request. Invoked by message originator.
				 * This message is intended only for the Coordinator.
				 */
				case '!':
					recv_msg = line.substring(1);
					String rslt = HandleCoordinatorInsert(recv_msg);

					/* Send success reply on the same socket */
					// if (rslt.equals("success")) {
					PrintWriter output;
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					// output.close();
					// }
					break;
					
				/*
				 * Replica1 Insert Request. Invoked by message originator when
				 * the Coordinator is dead.
				 */
				case '$':
					recv_msg = line.substring(1);
					rslt = HandleReplica1Insert(recv_msg);

					/* Send success reply on the same socket */
					// if (rslt.equals("success")) {
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					// output.close();
					// }
					break;
				/*
				 * Directed Insert in DB. Invoked by either the Coordinator or
				 * the Replica1
				 */
				case '&':
					recv_msg = line.substring(1);
					rslt = HandleDirectInsert(recv_msg);

					/* Send success reply on the same socket */
					// if (rslt.equals("success")) {
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println("success");
					output.flush();
					// output.close();
					// }
					break;

				/*
				 * Coordinator Query/Read Request. Invoked by message
				 * originator. This message is intended only for the
				 * Coordinator.
				 */
				case '@':
					recv_msg = line.substring(1);
					rslt = HandleCoordinatorQuery(recv_msg);

					/* Send success reply on the same socket */
					// if (!rslt.equals("failure")) {
					// PrintWriter output;
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					// output.close();
					// }
					break;

				case '%':
					recv_msg = line.substring(1);
					rslt = HandleReplica1Query(recv_msg);

					/* Send success reply on the same socket */
					// if (!rslt.equals("failure")) {
					// PrintWriter output;
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					// output.close();
					// }

					break;

				/*
				 * Case for direct query. Invoked by the Coordinator or by his
				 * first successor
				 */
				case '^':
					recv_msg = line.substring(1);
					rslt = HandleDirectQuery(recv_msg);

					/* Send success reply on the same socket */
					// if (!rslt.equals("failure")) {
					// PrintWriter output;
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					// output.close();
					// }
					break;

				/* Case for QuorumCheck conditions. */
				case '#':
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println("success");
					output.flush();
					break;
					
				case '~':
					
					recv_msg = line.substring(1);
					Log.d("Within Server of " + DynamoContentProvider.PORT_NO,"Calling PORT = " + recv_msg);
					rslt = GetAllMyValues(recv_msg);
					Log.d("Within Server of " + DynamoContentProvider.PORT_NO, "Result String = " + rslt);
					
					output = new PrintWriter(soc.getOutputStream(), true);
					output.println(rslt);
					output.flush();
					break;
					
				default:
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.d("Inside Server", e.getMessage());
		}

	}

	private String GetAllMyValues(String recv_msg) {
		
		String trgt_port = recv_msg;
		
		Cursor qryCursor = DynamoContentProvider.queryAllFromDB();
		String retVal = "";
		
		if (qryCursor != null) {
			qryCursor.moveToFirst();
			
			while (qryCursor.isAfterLast() == false) {
				
				String key = qryCursor.getString(0);
				String value = qryCursor.getString(1);
							
				String dest_ports = DynamoContentProvider.determineAllDestinations(key);
				
				int pos1 = dest_ports.indexOf("*");
				int pos2 = dest_ports.indexOf("*", pos1+1);
				
				String all_ports[] = new String[3];
				all_ports[0] = dest_ports.substring(0, pos1);
				all_ports[1] = dest_ports.substring(pos1+1 , pos2);
				all_ports[2] = dest_ports.substring(pos2+1);
								
				if(trgt_port.equals(all_ports[0]) || trgt_port.equals(all_ports[1]) || trgt_port.equals(all_ports[2])){
					retVal = retVal + "~" + key + "," + value;	
				}
				qryCursor.moveToNext();
			}
			
			return retVal;
		}
		else{
			return "noValues";
		}
		
	}

	/* Handles a direct insert into the DB. Does no processing. */
	private String HandleDirectInsert(String recv_msg) {

		int pos1 = recv_msg.indexOf("!");

		// Insert in Database
		String key = recv_msg.substring(0, pos1);
		String value = recv_msg.substring(pos1 + 1);
		DynamoContentProvider.insertIntoDB(key, value);

		return "success";
	}

	private String HandleReplica1Insert(String recv_msg) {

		int pos1 = recv_msg.indexOf("!");

		// Insert in Database.
		String key = recv_msg.substring(0, pos1);
		String value = recv_msg.substring(pos1 + 1);
		DynamoContentProvider.insertIntoDB(key, value);

		// Unicast message to Replica2 (which is my Successor 1)
		recv_msg = "&" + recv_msg;
		try {
			String rslt = MyServer.UnicastToDevice(
					DynamoContentProvider.SUCCESSOR_1, recv_msg);

			if (rslt == null || !rslt.equals("success")) {
				return rslt;
			}

			return rslt;

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("Replication2 Failed", "Successful on"
					+ DynamoContentProvider.PORT_NO + "msg" + value);
		}

		return null;
	}

	private String HandleCoordinatorInsert(String recv_msg) {

		int pos1 = recv_msg.indexOf("!");

		// Insert in Database
		String key = recv_msg.substring(0, pos1);
		String value = recv_msg.substring(pos1 + 1);
		String rslt = DynamoContentProvider.insertIntoDB(key, value);

		// Unicast message to both the Replicas -
		recv_msg = "&" + recv_msg;
		try {

			String rslt1 = MyServer.UnicastToDevice(
					DynamoContentProvider.SUCCESSOR_1, recv_msg);

			String rslt2 = MyServer.UnicastToDevice(
					DynamoContentProvider.SUCCESSOR_2, recv_msg);

			if (rslt.equals("success")) {
				// ***************Changed 2/25
				// if (rslt1 == null || !rslt1.equals("success")) {
				if (rslt1.equals("failure")) {
					Log.d("HandleCoordinator",
							"1st Replication failed. Coordinator Device: "
									+ DynamoContentProvider.PORT_NO + "msg"
									+ value);

					// ************** Changed 2/25
					// if (rslt2 == null || !rslt2.equals("success")) {
					if (rslt2.equals("failure")) {
						Log.d("HandleCoordinator",
								"2nd Replication failed. Coordinator Device: "
										+ DynamoContentProvider.PORT_NO + "msg"
										+ value);
						return "failure";
					}

					else {
						Log.d("HandleCoordinator",
								"The 2nd Replication passed. Coordinator Device: "
										+ value);
						return "success";
					}
				} else if (rslt1.equals("success")){
					Log.d("HandleCoordinator",
								"The 1st Replication passed. Coordinator Device: "
										+ value);
					if(rslt2.equals("failure")){
						Log.d("HandleCoordinator",
								"The 2nd Replication failed. Coordinator Device: "
										+ value);

					}
					return "success";
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("HandleCoordinator", e.getMessage());
		}
		return "failure";
	}

	/* Direct Query from node */
	private String HandleDirectQuery(String recv_msg) {

		// Query from Database
		String key = recv_msg;
		Cursor qryCursor = DynamoContentProvider.queryFromDB(key);

		// Send message to the Test Initiator on my local DB.
		if (qryCursor != null) {
			qryCursor.moveToFirst();
			key = qryCursor.getString(0);
			String value = qryCursor.getString(1);
			value = "success" + "!" + key + "," + value;
			return value;
		}
		return "failure";
	}

	private String HandleReplica1Query(String recv_msg) {

		try {
			// Query from Database
			String key = recv_msg;
			Cursor qryCursor = DynamoContentProvider.queryFromDB(key);

			// Send message to the Test Initiator that the message is stored
			// on my local DB.
			if (qryCursor != null) {
				qryCursor.moveToFirst();
				key = qryCursor.getString(0);
				String value = qryCursor.getString(1);

				/* Send Direct Query Message to Successor 1 */
				String msg = "^" + key;
				String rslt1 = UnicastToDevice(
						DynamoContentProvider.SUCCESSOR_1, msg);

				/* Because both the nodes have failed */
				if (rslt1.equals("failure")) {
					return "failure";
				}

				else {

					int pos3 = rslt1.indexOf("!");
					int pos4 = rslt1.indexOf(",", pos3 + 1);
					String value2 = rslt1.substring(pos4 + 1);

					if (value.equals(value2)) {
						value = "success" + "!" + key + "," + value;
						return value;
					}

					else {
						return "failure";
					}

				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.d("HandleReplica1Query", e.getMessage());
		}

		return null;
	}

	/* Function to Handle Coordinated query. Also checks the read quorum. */
	private String HandleCoordinatorQuery(String recv_msg) {

		try {
			// Query from Database
			String key = recv_msg;
			Cursor qryCursor = DynamoContentProvider.queryFromDB(key);

			// Send message to the Test Initiator that the message is stored
			// on my local DB.
			if (qryCursor != null) {
				qryCursor.moveToFirst();
				key = qryCursor.getString(0);
				String value = qryCursor.getString(1);

				/* Send Direct Query Message to Successor 1 */
				String msg = "^" + key;
				String rslt1 = UnicastToDevice(
						DynamoContentProvider.SUCCESSOR_1, msg);

				String rslt2 = UnicastToDevice(
						DynamoContentProvider.SUCCESSOR_2, msg);
				
				/*
				 * Indicates that the Successor1 is either dead or doesn't have
				 * the given key. Send a Direct Query Message to Successor 2
				 */
				if (rslt1.equals("failure")) {

//					String rslt2 = UnicastToDevice(
//							DynamoContentProvider.SUCCESSOR_2, msg);
					/* Replica 2 failed too */
					if (rslt2.equals("failure")) {
						return "failure";
					}

					else {

						int pos3 = rslt2.indexOf("!");
						int pos4 = rslt2.indexOf(",", pos3 + 1);
						String value2 = rslt2.substring(pos4 + 1);

						if (value.equals(value2)) {
							value = "success" + "!" + key + "," + value;
							return value;
						}

						else {
							return "failure";
						}
					}

				}

				else {
//					String rslt2 = UnicastToDevice(
//							DynamoContentProvider.SUCCESSOR_2, msg);
					/* Successor 2 failed but Successor 1 passed */
					if (rslt2.equals("failure")) {

						int pos1 = rslt1.indexOf("!");
						int pos2 = rslt1.indexOf(",", pos1 + 1);
						String value1 = rslt1.substring(pos2 + 1);

						if (value.equals(value1)) {
							value = "success" + "!" + key + "," + value;
							return value;
						}

						else {
							Log.d("Query","Read Quorum failed for consistency");
							return "failure";
						}
					}

					/*
					 * Successor 2 passes too. Check for consistency between any
					 * two values
					 */
					else {

						int pos1 = rslt1.indexOf("!");
						int pos2 = rslt1.indexOf(",", pos1 + 1);
						String value1 = rslt1.substring(pos2 + 1);

						int pos3 = rslt2.indexOf("!");
						int pos4 = rslt2.indexOf(",", pos3 + 1);
						String value2 = rslt2.substring(pos4 + 1);

						if (value.equals(value1)) {
							value = "success" + "!" + key + "," + value;
							return value;
						}

						else if (value.equals(value2)) {
							value = "success" + "!" + key + "," + value;
							return value;
						}

						else if (value1.equals(value2)) {
							value1 = "success" + "!" + key + "," + value1;
							return value1;
						}

						/* No consistency between values */
						else {
							Log.d("Query","Read Quorum failed for consistency");
							return "failure";
						}

					}
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "failure";
	}

	public static String UnicastToDevice(String next_node, String msg) {

		int dest_port = Integer.parseInt(next_node) * 2;

		Socket clientSoc;
		try {
			clientSoc = new Socket("10.0.2.2", dest_port);
			BufferedReader input = new BufferedReader(new InputStreamReader(
					clientSoc.getInputStream()));
			PrintWriter output;
			output = new PrintWriter(clientSoc.getOutputStream(), true);
			output.println(msg);
			output.flush();

			clientSoc.setSoTimeout(3000);
			String line = input.readLine();

			// if (line == null) {
			// Log.d("UnicastToDevice", "Unicast read null");
			// return line;
			// }

			clientSoc.close();
			if (line == null) {
				return "failure";
			}

			return line;

		} catch (SocketTimeoutException e1) {
			e1.printStackTrace();
			Log.d("Unicast to Device", "Socket Timeout at device: "
					+ DynamoContentProvider.PORT_NO);
			return "failure";

		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		return "failure";
	}

}
