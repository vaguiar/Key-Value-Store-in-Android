package edu.buffalo.cse.cse486_586.simpledynamo;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
import java.util.HashMap;
import java.util.List;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Log;

public class DynamoContentProvider extends ContentProvider {

	public static final String AUTHORITY = "content://edu.buffalo.cse.cse486_586.simpledynamo.provider";
	public static Uri CONTENT_URI = Uri.parse(AUTHORITY);

	// Defining all the private variables
	private static final String DATABASE = "MyDatabase";
	private static final int DB_VERSION = 1;
	private static final String TABLE_NAME = "MyTable";
	private static final String TEMP_TABLE = "TempTable";
	private static MyStarterClass starterObj;
	private static MyServer serverObj;
	private static MyClient clientObj;
	private static int INDEX;
	private static final int NUMBER_OF_NODES = 5;
	private static final int LAST_NODE = 5562;
	private static final int QUORUM_NUMBER = 2;

	// Defining all public variables
	public static final String PROVIDER_KEY = "provider_key";
	public static final String PROVIDER_VALUE = "provider_value";
	public static List<MemberNodes> MEMBER_NODES = new ArrayList<MemberNodes>();
	public static String PORT_NO;
	public static String SUCCESSOR_1;
	public static String SUCCESSOR_2;
	public static String PREDECESSOR_1;
	public static String PREDECESSOR_2;
	public static MemberNodes node_obj;
	public static HashMap<String, String> CURSOR_MAP = new HashMap<String, String>();

	/*
	 * ------------------------------ SuperClass functions
	 * --------------------------------
	 */

	/* Starter Class */
	private static class MyStarterClass extends SQLiteOpenHelper {

		public MyStarterClass(Context context) {
			super(context, DATABASE, null, DB_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase createDb) {

			// Step 1: Instantiate and create the database
			String table = ("CREATE TABLE " + TABLE_NAME + " (" + PROVIDER_KEY
					+ " Provider Key String," + PROVIDER_VALUE + " Provider Value String );");
			try {
				createDb.execSQL(table);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		@Override
		public void onUpgrade(SQLiteDatabase sqlDb, int oldversion,
				int newversion) {
			sqlDb.execSQL("drop table if exists " + TABLE_NAME);
			sqlDb.execSQL("drop table if exists " + TEMP_TABLE);
			this.onCreate(sqlDb);
		}
	}

	/* Hash Function Generator */
	public static String genHash(String input) throws NoSuchAlgorithmException {
		MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
		byte[] sha1Hash = sha1.digest(input.getBytes());
		Formatter formatter = new Formatter();
		for (byte b : sha1Hash) {
			formatter.format("%02x", b);
		}
		return formatter.toString();
	}

	/*
	 * Goes to through successors as well as predecessors to update the newly
	 * joined node
	 */
	private void getUpdates() {

		String rslt1 = GetMyValues(SUCCESSOR_1);
		if (rslt1.equals("failure")) {
			String rslt2 = GetMyValues(SUCCESSOR_2);
			if (rslt2.equals("failure")) {
				Log.d("Inside GetUpdates",
						"Node Failure on both Succesor Nodes");
			}
		}
		String rslt3 = GetMyValues(PREDECESSOR_1);
		if (rslt3.equals("failure")) {
			String rslt4 = GetMyValues(PREDECESSOR_2);
			if (rslt4.equals("failure")) {
				Log.d("Inside GetUpdates",
						"Node Failure on both Predecessor Nodes");
			}
		}
	}

	private String GetMyValues(String port) {

		try {
			clientObj = new MyClient();
			clientObj.MSG = "~" + PORT_NO;
			clientObj.MY_PORT = port;
			
			Log.d("GetMyValues", PORT_NO + "is trying to contact" + port);
			
			Thread getThread = new Thread(clientObj);
			getThread.start();
			getThread.join();

			int pos1 = 0;
			int pos2 = 0;

			if(clientObj.RESULT.equals("failure")){
				return "failure";
			}
			
			else if(clientObj.RESULT.equals("noValues")){
				return "noValues";
			}
						
			else if(!clientObj.RESULT.equals("failure") && !clientObj.RESULT.equals("noValues")) {

				Log.d("GetMyValues","String of Values: " + clientObj.RESULT);
				
				pos1 = clientObj.RESULT.indexOf("~", pos2);

				while (pos1 != -1 && pos2 != -1) {

					pos2 = clientObj.RESULT.indexOf(",", pos1 + 1);
					String key = clientObj.RESULT.substring(pos1 + 1, pos2);

					pos1 = clientObj.RESULT.indexOf("~", pos2 + 1);
					String value = "";
					if(pos1 == -1){
						value = clientObj.RESULT.substring(pos2 + 1);
					}
					else{
						value = clientObj.RESULT.substring(pos2 + 1, pos1);
					}
					insertIntoDB(key, value);
					
				}

				return "success";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "failure";
	}

	/*
	 * Sorts the nodes within the List MEMBER_NODES and assigns the
	 * corresponding values of the both the successors and predecessors
	 */
	private void nodeSort() {
		try {
			Collections.sort(MEMBER_NODES);
			node_obj = new MemberNodes();

			/* To find the index of the current port */
			for (int i = 0; i < MEMBER_NODES.size(); i++) {
				node_obj = MEMBER_NODES.get(i);
				if (node_obj.node.equals(PORT_NO)) {
					INDEX = i;
					break;
				}
			}

			/* Get both the successors */
			node_obj = MEMBER_NODES.get((INDEX + 1) % NUMBER_OF_NODES);
			SUCCESSOR_1 = node_obj.node;

			node_obj = MEMBER_NODES.get((INDEX + 2) % NUMBER_OF_NODES);
			SUCCESSOR_2 = node_obj.node;

			/* Get both the predecessors */
			node_obj = MEMBER_NODES.get((INDEX + NUMBER_OF_NODES - 1)
					% NUMBER_OF_NODES);
			PREDECESSOR_1 = node_obj.node;

			node_obj = MEMBER_NODES.get((INDEX + NUMBER_OF_NODES - 2)
					% NUMBER_OF_NODES);
			PREDECESSOR_2 = node_obj.node;

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("nodeSort", e.getMessage());
		}

	}

	/*
	 * Function to determine the Coordinator, Successor and Predecessor of a
	 * particular message
	 */
	public static String determineAllDestinations(String key) {

		try {
			String msg_id = genHash(key);
			node_obj = new MemberNodes();
			String dest_ports;

			// To find the coordinator's index
			for (int i = 0; i < MEMBER_NODES.size(); i++) {
				node_obj = MEMBER_NODES.get(i);
				if (msg_id.compareTo(node_obj.node_id) <= 0) {
					INDEX = i;
					break;
				}
				/*
				 * If it is greater than all the nodes then assign it to the
				 * first node due to the cyclic nature of the Chord
				 */
				else if (i == (MEMBER_NODES.size() - 1)) {
					INDEX = 0;
					break;
				}
			}

			// Get the Coordinator node
			node_obj = MEMBER_NODES.get(INDEX);
			dest_ports = node_obj.node;

			// Get the first successor node
			node_obj = MEMBER_NODES.get((INDEX + 1) % NUMBER_OF_NODES);
			dest_ports = dest_ports + "*" + node_obj.node;

			// Get the second successor node
			node_obj = MEMBER_NODES.get((INDEX + 2) % NUMBER_OF_NODES);
			dest_ports = dest_ports + "*" + node_obj.node;

			return dest_ports;

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("determineAllDestinations", e.getMessage());
		}
		return null;
	}

	/*
	 * Function responsible for inserting values into the DB First check if the
	 * key exists, if it does, then update, else insert
	 */
	public static String insertIntoDB(String key, String value) {

		ContentValues keyValueToInsert = new ContentValues();
		keyValueToInsert.put(PROVIDER_KEY, key);
		keyValueToInsert.put(PROVIDER_VALUE, value);

		SQLiteDatabase myDb = starterObj.getWritableDatabase();

		SQLiteDatabase sqlDb = starterObj.getReadableDatabase();

		Cursor check_db_first = sqlDb.query(TABLE_NAME, null, PROVIDER_KEY
				+ "= '" + key + "'", null, null, null, null);

		if (check_db_first.moveToFirst() == false) {

			long rowId = myDb.insertOrThrow(TABLE_NAME, null, keyValueToInsert);
			Log.d("Insert Into DB", "msg:" + value + " in port:" + PORT_NO);

			try {
				if (rowId == -1) {
					throw new RuntimeException(String.format(
							"%s: Error inserting [%s] to [%s].",
							" In insert()", keyValueToInsert, CONTENT_URI));

				}
				return "success";
			} finally {
				// check_db_first.close();
				myDb.close();
			}
		} else {
			keyValueToInsert = new ContentValues();
			keyValueToInsert.put(PROVIDER_VALUE, value);

			myDb.update(TABLE_NAME, keyValueToInsert, PROVIDER_KEY + "= '"
					+ key + "'", null);
			Log.d("Insert Into DB", "msg:" + value + " in port:" + PORT_NO);
			return "success";
		}

	}

	/* Function responsible for querying values from the DB */
	public static Cursor queryFromDB(String key) {

		SQLiteDatabase sqlDb = starterObj.getReadableDatabase();

		return sqlDb.query(TABLE_NAME, null, PROVIDER_KEY + "= '" + key + "'",
				null, null, null, null);
	}

	/* Function responsible for querying all the values from the DB */
	public static Cursor queryAllFromDB() {

		SQLiteDatabase sqlDb = starterObj.getReadableDatabase();

		return sqlDb.query(TABLE_NAME, null, null, null, null, null,
				null);
	}

	/* Function to check the quorum to see if the nodes are alive */
	private String quorumCheck(String dest_ports) {

		try {
			int pos1 = dest_ports.indexOf("*");
			int pos2 = dest_ports.indexOf("*", pos1 + 1);

			String cur_dest[] = new String[3];

			cur_dest[0] = dest_ports.substring(0, pos1);
			cur_dest[1] = dest_ports.substring(pos1 + 1, pos2);
			cur_dest[2] = dest_ports.substring(pos2 + 1);

			int pass_count = 0;

			for (int i = 0; i < 3; i++) {

				clientObj = new MyClient();
				clientObj.MY_PORT = cur_dest[i];
				clientObj.MSG = "#";

				Thread quorumThread = new Thread(clientObj);
				quorumThread.start();

				quorumThread.join();

				if (clientObj.RESULT.equals("success")) {
					pass_count++;
				}
			}

			if (pass_count >= QUORUM_NUMBER) {
				return "success";
			} else {
				return "failure";
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
			Log.d("QuorumCheckFunction", "Quorum Check Function Failed");
		}

		return "failure";
	}

	/*
	 * ------------------------------ End of SuperClass functions
	 * --------------------------------
	 */

	@Override
	public boolean onCreate() {

		try {
			// Step 1: Call the constructor of MyStarterClass
			starterObj = new MyStarterClass(getContext());

			/* Port Number Generator Function */
			TelephonyManager tel = (TelephonyManager) getContext()
					.getSystemService(Context.TELEPHONY_SERVICE);
			String portStr = tel.getLine1Number().substring(
					tel.getLine1Number().length() - 4);

			// Step 2: Fetch and Update PORT_NO
			PORT_NO = portStr;

			// Step 3: Populate my MEMBER_NODES list
			for (Integer i = 5554; i <= LAST_NODE; i = i + 2) {
				node_obj = new MemberNodes();
				node_obj.node = i.toString();
				node_obj.node_id = genHash(i.toString());
				MEMBER_NODES.add(node_obj);
			}

			// Step 4: Rearrange all the nodes based on their NodeIds.
			nodeSort();
			//
			Log.d("Pred1 ", PREDECESSOR_1);
			Log.d("Pred2 ", PREDECESSOR_2);
			Log.d("Succ1 ", SUCCESSOR_1);
			Log.d("Succ2 ", SUCCESSOR_2);

			// Step 5: Getting Updates from my successors and my predecessors
			getUpdates();
	
			// Step 6: Call the Server Thread
			serverObj = new MyServer();
			Thread serverThread = new Thread(serverObj);
			serverThread.start();

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("Overridden OnCreate", e.getMessage());
		}
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		try {
			String orderBy;
			if (TextUtils.isEmpty(sortOrder)) {
				orderBy = PROVIDER_KEY;
			} else {
				orderBy = sortOrder;
			}

			SQLiteDatabase sqlDb = starterObj.getReadableDatabase();

			/* Called by the OnClickDump function */
			if (selection == null) {
				return sqlDb.query(TABLE_NAME, null, null, null, null, null,
						orderBy);
			}

			/*
			 * Called by anyone who wants to query a particular KEY Also invoked
			 * by the ONClickTest function
			 */
			else {
				Cursor my_cursor = null;

				String dest_ports = determineAllDestinations(selection);
				if (dest_ports != null) {

					String quorum_rslt = quorumCheck(dest_ports);

					if (quorum_rslt.equals("failure")) {
						throw new Exception(
								"Read Quorum failed int quorum check function for the key:"
										+ selection);
					}

					int pos1 = dest_ports.indexOf("*");
					int pos2 = dest_ports.indexOf("*", pos1 + 1);

					/*
					 * Implements the Read Quorum by sending the message first
					 * to the coordinator, which takes turns to send it to each
					 * of the replica's individually. If the coordinator doesn't
					 * return a success or if it times-out, then the message is
					 * sent to Replica1 which again checks for Quorum between
					 * itself and the next Replica. If this returns a failure
					 * too, then the Quorum is considered to be failed.
					 */

					String coordinator = dest_ports.substring(0, pos1);
					String msg = "@" + selection;

					clientObj = new MyClient();
					clientObj.MY_PORT = coordinator;
					clientObj.MSG = msg;
					Thread clientThread = new Thread(clientObj);
					clientThread.start();
					clientThread.join();

					/*
					 * Reading failed from Coordinator. Hence send request to
					 * Replica1
					 */
					if (clientObj.RESULT.equals("failure")) {

						String replica1 = dest_ports.substring(pos1 + 1, pos2);
						msg = "%" + msg.substring(1);

						clientObj = new MyClient();
						clientObj.MSG = msg;
						clientObj.MY_PORT = replica1;
						Thread clientThrd1 = new Thread(clientObj);
						clientThrd1.start();
						clientThrd1.join();

						if (clientObj.RESULT.equals("failure")) {
							throw new Exception(
									"Read Quorum failed for both the msg key:"
											+ selection);
						}
					}

					/*
					 * Obtain the key and value returned from the result of the
					 * query
					 */
					int pos3 = clientObj.RESULT.indexOf("!");
					int pos4 = clientObj.RESULT.indexOf(",");

					String cur_key = clientObj.RESULT.substring(pos3 + 1, pos4);
					String cur_value = clientObj.RESULT.substring(pos4 + 1);

					Log.d("DynamoCP Queried", "key:" + cur_key + " , msg:"
							+ cur_value);

					// /* Waits on the values to get the CURSOR_MAP populated */
					// synchronized (CURSOR_MAP) {
					// CURSOR_MAP.wait();
					// }

					/* Creating a temporary table */
					String table = ("CREATE TABLE " + TEMP_TABLE + " ("
							+ PROVIDER_KEY + " Provider Key String,"
							+ PROVIDER_VALUE + " Provider Value String );");

					sqlDb.execSQL("drop table if exists " + TEMP_TABLE);

					sqlDb.execSQL(table);

					/* Add values into TEMP_TABLE */
					ContentValues keyValueToInsert = new ContentValues();
					keyValueToInsert.put(DynamoContentProvider.PROVIDER_KEY,
							cur_key);
					keyValueToInsert.put(DynamoContentProvider.PROVIDER_VALUE,
							cur_value);

					SQLiteDatabase myDb = DynamoContentProvider.starterObj
							.getWritableDatabase();

					long rowId = myDb.insertOrThrow(TEMP_TABLE, null,
							keyValueToInsert);

					if (rowId == -1) {
						throw new RuntimeException(String.format(
								"%s: Error inserting [%s] to [%s].",
								" In insert()", keyValueToInsert, CONTENT_URI));

					}
				}

				/* And point the cursor to the Temp_Table */
				my_cursor = sqlDb.query(TEMP_TABLE, null, PROVIDER_KEY + "= '"
						+ selection + "'", null, null, null, null);

				if (my_cursor != null) {
					return my_cursor;
				} else {
					return null;
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("Inside Query", e.getMessage());
		}

		return null;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {

		try {
			String key = values.getAsString(PROVIDER_KEY);
			String msg = values.getAsString(PROVIDER_VALUE);

			String dest_ports = determineAllDestinations(key);
			if (dest_ports != null) {

				String quorum_rslt = quorumCheck(dest_ports);
				if (quorum_rslt.equals("failure")) {
					throw new Exception(
							"Write Quorum failed in quorum check funtion for the msg key:"
									+ key);
				}

				int pos1 = dest_ports.indexOf("*");
				int pos2 = dest_ports.indexOf("*", pos1 + 1);

				String coordinator = dest_ports.substring(0, pos1);
				msg = "!" + key + "!" + msg;

				clientObj = new MyClient();
				clientObj.MSG = msg;
				clientObj.MY_PORT = coordinator;
				Thread clientThrd = new Thread(clientObj);
				clientThrd.start();
				clientThrd.join();

				/* Writing failed on Coordinator Hence send to Replica1 */
				// Changes made - if (!clientObj.RESULT.equals("success")) {
				// 4/25/2012
				if (clientObj.RESULT.equals("failure")) {

					String replica1 = dest_ports.substring(pos1 + 1, pos2);
					msg = "$" + msg.substring(1);

					clientObj = new MyClient();
					clientObj.MSG = msg;
					clientObj.MY_PORT = replica1;
					Thread clientThrd1 = new Thread(clientObj);
					clientThrd1.start();
					clientThrd1.join();

					// Changes made - if (!clientObj.RESULT.equals("success")) {
					// 4/25/2012
					if (!clientObj.RESULT.equals("success")) {
						throw new Exception("Write Quorum Failed for msg:"
								+ msg);
					} else {
						Log.d("DynamoCP Insert", "key:" + key + " , msg:" + msg);
					}
				}
			}

		} catch (Exception e1) {
			e1.printStackTrace();
			Log.d("DynamoCP Insert", e1.getMessage());
		}

		return null;

	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		int rowCount = 0;
		int tempRowCount = 0;
		SQLiteDatabase sqlDb = DynamoContentProvider.starterObj
				.getWritableDatabase();
		try {
			rowCount = sqlDb.delete(TABLE_NAME, selection, selectionArgs);
			tempRowCount = sqlDb.delete(TABLE_NAME, selection, selectionArgs);
			rowCount = rowCount + tempRowCount;
		} finally {
			sqlDb.close();
		}
		return rowCount;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return 0;
	}

}
