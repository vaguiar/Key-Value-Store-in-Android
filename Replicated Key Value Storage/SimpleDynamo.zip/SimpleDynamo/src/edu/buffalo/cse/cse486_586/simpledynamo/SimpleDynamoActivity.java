package edu.buffalo.cse.cse486_586.simpledynamo;

import java.util.ArrayList;
import android.app.ListActivity;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;

public class SimpleDynamoActivity extends ListActivity {
	/** Called when the activity is first created. */

	Button put1_button;
	Button put2_button;
	Button put3_button;
	Button get_button;
	Button dump_button;
	Handler handle_thrd = new Handler();
	ArrayAdapter<String> m_arrayAdapter;

	/* Private variables */
	private static int KEY;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		put1_button = (Button) findViewById(R.id.button1);
		put2_button = (Button) findViewById(R.id.button2);
		put3_button = (Button) findViewById(R.id.button3);
		get_button = (Button) findViewById(R.id.button4);
		dump_button = (Button) findViewById(R.id.button5);

		ArrayList<String> lst = new ArrayList<String>();
		m_arrayAdapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, android.R.id.text1, lst);
		setListAdapter(m_arrayAdapter);

		// // Step 1: Call Content Provider to Delete previous entries.
		// try {
		// int delRows = getContentResolver().delete(
		// DynamoContentProvider.CONTENT_URI, null, null);
		// Log.d("Activity", "Deleted Rows:" + delRows);
		//
		// } catch (Exception e) {
		// e.printStackTrace();
		// Log.d("Activity", e.getMessage());
		// }

		Log.d("Main Activity", "Node is up with updates");
	}

	public void ClearEverything(View v)
	{
		 // Step 1: Call Content Provider to Delete previous entries.
		 try {
		 int delRows = getContentResolver().delete(
		 DynamoContentProvider.CONTENT_URI, null, null);
		 Log.d("Activity", "Deleted Rows:" + delRows);
		 m_arrayAdapter.clear();
		 } catch (Exception e) {
		 e.printStackTrace();
		 Log.d("Activity", e.getMessage());
		 }
	}
	/* Function to handle the click of the Put1 Button */
	public void OnClickPut1(View v) {

		m_arrayAdapter.clear();
		
		// public void run() {
		try {
			/* Reset Key each time Test is called */
			KEY = 0;

			/*
			 * Generate 10 Put1 messages that have to be inserted into the DHT
			 */
			m_arrayAdapter.add("Inserting Put1 test values over the DHT...");
			for (KEY = 0; KEY <= 9; KEY++) {

				Thread.sleep(3000);

				ContentValues keyValueToInsert = new ContentValues();
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_KEY, KEY);
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_VALUE,
						"Put1" + KEY);

				Uri newUri = getContentResolver().insert(
						DynamoContentProvider.CONTENT_URI, keyValueToInsert);

			}
			m_arrayAdapter.add("Inserted all Put1 test values...");
		} catch (Exception e) {
			e.printStackTrace();
			Log.d("OnclickPut1", e.getMessage());
		}
		// }

		// });

	}

	
	/* Function to handle the click of the Put2 Button */
	public void OnClickPut2(View v) {

		m_arrayAdapter.clear();
		
		try {
			/* Reset Key each time Test is called */
			KEY = 0;

			// Step 1: Call Content Provider to Delete previous entries.
			// int delRows = getContentResolver().delete(
			// DynamoContentProvider.CONTENT_URI, null, null);
			// Log.d("Activity", "Deleted Rows:" + delRows);

			/*
			 * Generate 10 Put2 messages that have to be inserted into the DHT
			 */
			m_arrayAdapter.add("Inserting Put2 test values over the DHT...");
			for (KEY = 0; KEY <= 9; KEY++) {

				Thread.sleep(3000);

				ContentValues keyValueToInsert = new ContentValues();
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_KEY, KEY);
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_VALUE,
						"Put2" + KEY);

				Uri newUri = getContentResolver().insert(
						DynamoContentProvider.CONTENT_URI, keyValueToInsert);

			}
			m_arrayAdapter.add("Inserted all Put2 test values...");
		} catch (Exception e) {
			e.printStackTrace();
			Log.d("OnclickPut2", e.getMessage());
		}

	}

	/* Function to handle the click of the Put3 Button */
	public void OnClickPut3(View v) {

		m_arrayAdapter.clear();
		
		try {
			/* Reset Key each time Test is called */
			KEY = 0;

			// Step 1: Call Content Provider to Delete previous entries.
			// int delRows = getContentResolver().delete(
			// DynamoContentProvider.CONTENT_URI, null, null);
			// Log.d("Activity", "Deleted Rows:" + delRows);

			/*
			 * Generate 10 Put3 messages that have to be inserted into the DHT
			 */
			m_arrayAdapter.add("Inserting Put3 test values over the DHT...");
			for (KEY = 0; KEY <= 9; KEY++) {

				Thread.sleep(3000);

				ContentValues keyValueToInsert = new ContentValues();
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_KEY, KEY);
				keyValueToInsert.put(DynamoContentProvider.PROVIDER_VALUE,
						"Put3" + KEY);

				Uri newUri = getContentResolver().insert(
						DynamoContentProvider.CONTENT_URI, keyValueToInsert);

			}
			m_arrayAdapter.add("Inserted all Put3 test values...");
		} catch (Exception e) {
			e.printStackTrace();
			Log.d("OnclickPut3", e.getMessage());
		}

	}

	/*
	 * Function to handle the click of the Get button. Responsible for getting
	 * all the keys in the DHT.
	 */
	public void OnClickGet(View v) {

		m_arrayAdapter.clear();
		
		try {

			/*
			 * Generate 10 Test messages that have to be Queried from the DHT
			 */
			
			m_arrayAdapter.add("Getting all Values from the DHT...");
			
			for (KEY = 0; KEY <= 9; KEY++) {

				Thread.sleep(3000);

				Integer selection = KEY;

				Cursor qryCursor = getContentResolver().query(
						DynamoContentProvider.CONTENT_URI, null,
						selection.toString(), null, null);

				qryCursor.moveToFirst();
				while (qryCursor.isAfterLast() == false) {

					String key = qryCursor.getString(0);
					String value = qryCursor.getString(1);
					// StringBuilder str = new StringBuilder();
					// str.append(key + value);
					// text_view.append(str);
					m_arrayAdapter.add(key + "," + value);

					Log.d("Cursor Returns", value);
					qryCursor.moveToNext();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Log.d("OnClickGet", e.getMessage());
		}

	}

	/* Function to handle the click of the Dump Button */
	public void OnClickDump(View v) {

		m_arrayAdapter.clear();
		
		try {
			handle_thrd.post(new Runnable() {

				public void run() {

					Cursor qryCursor = getContentResolver().query(
							DynamoContentProvider.CONTENT_URI, null, null,
							null, null);

					Integer no = qryCursor.getCount();
					Log.d("No of rows: ", no.toString());

					m_arrayAdapter.add("Creating Dump from Local Storage....");

					qryCursor.moveToFirst();
					while (qryCursor.isAfterLast() == false) {

						String key = qryCursor.getString(0);
						String value = qryCursor.getString(1);
						// StringBuilder str = new StringBuilder();
						// str.append(key + value);
						m_arrayAdapter.add(key + "," + value);

						Log.d("Cursor Returns", value);
						qryCursor.moveToNext();
					}

				}
			});

		} catch (Exception e) {
			e.printStackTrace();
			Log.d("OnClickDump", e.getMessage());
		}

	}

}
