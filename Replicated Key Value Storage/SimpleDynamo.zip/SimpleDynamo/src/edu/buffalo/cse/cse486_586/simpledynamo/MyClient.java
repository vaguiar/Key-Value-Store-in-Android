package edu.buffalo.cse.cse486_586.simpledynamo;

public class MyClient implements Runnable{
	
	public String MY_PORT;
	public String MSG;
	public String RESULT;
	
	public void run() {
		RESULT = MyServer.UnicastToDevice(MY_PORT, MSG);
	}
	
}
