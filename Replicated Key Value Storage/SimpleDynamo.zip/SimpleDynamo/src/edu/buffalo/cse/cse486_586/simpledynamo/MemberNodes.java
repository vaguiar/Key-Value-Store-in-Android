package edu.buffalo.cse.cse486_586.simpledynamo;

public class MemberNodes implements Comparable<MemberNodes> {

	String node;
	String node_id;

	public int compareTo(MemberNodes another) {
		return this.node_id.compareTo(another.node_id);
	}

}
